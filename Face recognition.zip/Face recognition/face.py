import cv2
import time

cap = cv2.VideoCapture(0)

for x in range(141,151):
    ret, frame = cap.read()
    cv2.imshow("Frame",frame)
    ch = cv2.waitKey(800) 
    cv2.imwrite('/home/pi/Desktop/IFR/dataset/Yiwen.5.'+str(x)+'.jpg', frame)
    time.sleep(0.5)
    print(x)

cv2.destroyAllWindows()
cap.release()
print('Done')