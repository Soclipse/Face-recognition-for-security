import cv2
import RPi.GPIO as GPIO
import time


# ==================================================
# SETTINGS
# ==================================================

MODEL_PATH = '/home/pi/Desktop/IFR/recognizer.xml'

CASCADE_PATH = (
    '/home/pi/Desktop/IFR/'
    'haarcascade_frontalface_default.xml'
)

FACE_SIZE = (200, 200)

NAMES = {
    1: "Royden",
    2: "Yiwen"
}


# ==================================================
# FACE RECOGNITION SETTINGS
# ==================================================

# Lower = stricter
# 50 is a balance between detecting Royden/Yiwen
# and rejecting strangers
UNKNOWN_THRESHOLD = 50

# Same person must match this many times
MATCH_REQUIRED = 5

# Average the last 5 scores
MAX_SCORE_HISTORY = 5

# Minimum average displayed confidence
MIN_KNOWN_PERCENTAGE = 70


# ==================================================
# ULTRASONIC SETTINGS
# ==================================================

TRIG = 23
ECHO = 24

ACTIVATION_DISTANCE = 40


# ==================================================
# SERVO SETTINGS
# ==================================================

SERVO_PIN = 18

DOOR_OPEN_TIME = 5.0


# ==================================================
# BUTTON + BUZZER SETTINGS
# ==================================================

BUZZER_PIN = 6
BUTTON_PIN = 26

BUZZER_DURATION = 5.0


# ==================================================
# GPIO SETUP
# ==================================================

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)


# --------------------------
# ULTRASONIC
# --------------------------

GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

GPIO.output(TRIG, False)


# --------------------------
# SERVO
# --------------------------

GPIO.setup(SERVO_PIN, GPIO.OUT)

servo = GPIO.PWM(
    SERVO_PIN,
    50
)

servo.start(0)


# --------------------------
# BUZZER
# --------------------------

GPIO.setup(
    BUZZER_PIN,
    GPIO.OUT
)

GPIO.output(
    BUZZER_PIN,
    GPIO.LOW
)


# --------------------------
# BUTTON
# --------------------------

GPIO.setup(
    BUTTON_PIN,
    GPIO.IN,
    pull_up_down=GPIO.PUD_UP
)

time.sleep(0.5)


# ==================================================
# SERVO FUNCTION
# ==================================================

def set_servo_angle(angle):

    duty = 2.5 + (angle / 18.0)

    servo.ChangeDutyCycle(
        duty
    )

    time.sleep(0.25)

    servo.ChangeDutyCycle(0)


# Start door CLOSED
set_servo_angle(0)


# ==================================================
# ULTRASONIC DISTANCE FUNCTION
# ==================================================

def get_distance():

    GPIO.output(
        TRIG,
        False
    )

    time.sleep(
        0.000002
    )

    GPIO.output(
        TRIG,
        True
    )

    time.sleep(
        0.00001
    )

    GPIO.output(
        TRIG,
        False
    )


    # ------------------------------------------
    # WAIT FOR ECHO HIGH
    # ------------------------------------------

    timeout_start = time.time()

    while GPIO.input(ECHO) == 0:

        if (
            time.time()
            -
            timeout_start
            >
            0.03
        ):

            return 999


    pulse_start = time.time()


    # ------------------------------------------
    # WAIT FOR ECHO LOW
    # ------------------------------------------

    timeout_start = time.time()

    while GPIO.input(ECHO) == 1:

        if (
            time.time()
            -
            timeout_start
            >
            0.03
        ):

            return 999


    pulse_end = time.time()


    # ------------------------------------------
    # CALCULATE DISTANCE
    # ------------------------------------------

    pulse_duration = (
        pulse_end
        -
        pulse_start
    )

    distance = (
        pulse_duration
        *
        17150
    )

    return round(
        distance,
        1
    )


# ==================================================
# LOAD FACE MODEL
# ==================================================

recognizer = (
    cv2.face.LBPHFaceRecognizer_create()
)

recognizer.read(
    MODEL_PATH
)

print(
    "[INFO] Face model loaded"
)


# ==================================================
# LOAD FACE DETECTOR
# ==================================================

face_detector = cv2.CascadeClassifier(
    CASCADE_PATH
)

if face_detector.empty():

    print(
        "[ERROR] Cannot load Haar Cascade"
    )

    servo.stop()

    GPIO.cleanup()

    exit()


font = cv2.FONT_HERSHEY_SIMPLEX


# ==================================================
# START CAMERA
# ==================================================

print(
    "[INFO] Looking for camera..."
)

cam = cv2.VideoCapture(0)


# Try camera 1 if camera 0 fails
if not cam.isOpened():

    print(
        "[WARNING] Camera 0 cannot open"
    )

    cam.release()

    print(
        "[INFO] Trying camera 1..."
    )

    cam = cv2.VideoCapture(1)


if not cam.isOpened():

    print(
        "[ERROR] Cannot open camera"
    )

    servo.stop()

    GPIO.cleanup()

    exit()


# Camera resolution
cam.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    320
)

cam.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    240
)

cam.set(
    cv2.CAP_PROP_BUFFERSIZE,
    1
)


print(
    "[INFO] Camera opened successfully"
)

print(
    "[INFO] Recognition activates within 40 cm"
)

print(
    "[INFO] 5 consistent matches required"
)

print(
    "[INFO] Press ESC to exit"
)


# ==================================================
# VARIABLES
# ==================================================

frame_count = 0

recognition_results = []


# ==================================================
# FACE MATCH VARIABLES
# ==================================================

current_candidate = None

match_count = 0

score_history = []


# --------------------------
# SERVO VARIABLES
# --------------------------

door_open = False

door_open_start = 0

last_recognition_time = 0

recognition_cooldown = 3


# --------------------------
# BUZZER VARIABLES
# --------------------------

buzzer_on = False

buzzer_start = 0

button_was_pressed = False


# ==================================================
# RESET RECOGNITION FUNCTION
# ==================================================

def reset_recognition():

    global current_candidate
    global match_count
    global score_history

    current_candidate = None

    match_count = 0

    score_history.clear()


# ==================================================
# OPEN DOOR FUNCTION
# ==================================================

def open_door(name):

    global door_open
    global door_open_start
    global last_recognition_time


    current_time = time.time()


    if (
        not door_open
        and
        current_time
        -
        last_recognition_time
        >
        recognition_cooldown
    ):

        print(
            "[ACCESS GRANTED]",
            name
        )

        print(
            "[DOOR] Opening"
        )


        set_servo_angle(
            180
        )


        door_open = True

        door_open_start = (
            time.time()
        )

        last_recognition_time = (
            time.time()
        )


# ==================================================
# CALCULATE DISPLAY PERCENTAGE
# ==================================================

def calculate_percentage(face_distance):

    percentage = int(
        180
        -
        (
            face_distance
            *
            2
        )
    )


    if percentage > 100:

        percentage = 100


    if percentage < 0:

        percentage = 0


    return percentage


# ==================================================
# MAIN LOOP
# ==================================================

try:

    while True:


        # ==================================================
        # BUTTON + BUZZER
        # ==================================================

        button = GPIO.input(
            BUTTON_PIN
        )


        # ------------------------------------------
        # BUTTON PRESSED
        # ------------------------------------------

        if button == GPIO.LOW:

            if not button_was_pressed:

                button_was_pressed = True

                print(
                    "[BUTTON] Pressed"
                )


                if not buzzer_on:

                    print(
                        "[BUZZER] ON"
                    )

                    GPIO.output(
                        BUZZER_PIN,
                        GPIO.HIGH
                    )

                    buzzer_on = True

                    buzzer_start = (
                        time.time()
                    )


        # ------------------------------------------
        # BUTTON RELEASED
        # ------------------------------------------

        else:

            button_was_pressed = False


        # ------------------------------------------
        # BUZZER TIMER
        # ------------------------------------------

        if buzzer_on:

            buzzer_elapsed = (
                time.time()
                -
                buzzer_start
            )


            if (
                buzzer_elapsed
                >=
                BUZZER_DURATION
            ):

                GPIO.output(
                    BUZZER_PIN,
                    GPIO.LOW
                )

                buzzer_on = False

                print(
                    "[BUZZER] OFF"
                )


        # ==================================================
        # SERVO TIMER
        # ==================================================

        if door_open:

            door_elapsed = (
                time.time()
                -
                door_open_start
            )


            if (
                door_elapsed
                >=
                DOOR_OPEN_TIME
            ):

                print(
                    "[DOOR] Closing door"
                )

                set_servo_angle(
                    0
                )

                door_open = False


        # ==================================================
        # GET ULTRASONIC DISTANCE
        # ==================================================

        distance = get_distance()


        # ==================================================
        # READ CAMERA
        # ==================================================

        ret, img = cam.read()


        if not ret:

            print(
                "[ERROR] Cannot read camera"
            )

            break


        # Mirror camera
        img = cv2.flip(
            img,
            1
        )


        # ==================================================
        # DISPLAY DISTANCE
        # ==================================================

        if distance == 999:

            distance_text = (
                "Distance: No Echo"
            )

        else:

            distance_text = (
                "Distance: "
                +
                str(distance)
                +
                " cm"
            )


        cv2.putText(
            img,
            distance_text,
            (10, 20),
            font,
            0.45,
            (255, 255, 255),
            1
        )


        # ==================================================
        # DISPLAY DOOR STATUS
        # ==================================================

        if door_open:

            cv2.putText(
                img,
                "Door: OPEN",
                (10, 95),
                font,
                0.5,
                (0, 255, 0),
                1
            )

        else:

            cv2.putText(
                img,
                "Door: CLOSED",
                (10, 95),
                font,
                0.5,
                (0, 0, 255),
                1
            )


        # ==================================================
        # DISPLAY BUZZER STATUS
        # ==================================================

        if buzzer_on:

            cv2.putText(
                img,
                "Buzzer: ON",
                (10, 120),
                font,
                0.5,
                (0, 255, 0),
                1
            )

        else:

            cv2.putText(
                img,
                "Buzzer: OFF",
                (10, 120),
                font,
                0.5,
                (0, 0, 255),
                1
            )


        # ==================================================
        # WITHIN 40 CM
        # ==================================================

        if (
            distance != 999
            and
            distance <= ACTIVATION_DISTANCE
        ):


            cv2.putText(
                img,
                "Face Recognition: ACTIVE",
                (10, 45),
                font,
                0.45,
                (0, 255, 0),
                1
            )


            # ------------------------------------------
            # CONVERT TO GRAYSCALE
            # ------------------------------------------

            gray = cv2.cvtColor(
                img,
                cv2.COLOR_BGR2GRAY
            )


            # Improve contrast
            gray = cv2.equalizeHist(
                gray
            )


            frame_count += 1


            # ==================================================
            # DETECT EVERY 2 FRAMES
            # ==================================================

            if frame_count % 2 == 0:


                faces = (
                    face_detector.detectMultiScale(
                        gray,
                        scaleFactor=1.1,
                        minNeighbors=5,
                        minSize=(50, 50)
                    )
                )


                recognition_results = []


                # ==================================================
                # NO FACE
                # ==================================================

                if len(faces) == 0:

                    reset_recognition()


                # ==================================================
                # CHECK EACH FACE
                # ==================================================

                for (
                    x,
                    y,
                    w,
                    h
                ) in faces:


                    # ------------------------------------------
                    # CROP FACE
                    # ------------------------------------------

                    face = gray[
                        y:y+h,
                        x:x+w
                    ]


                    # ------------------------------------------
                    # RESIZE FACE
                    # ------------------------------------------

                    face = cv2.resize(
                        face,
                        FACE_SIZE
                    )


                    # ==================================================
                    # LBPH PREDICTION
                    # ==================================================

                    (
                        predicted_id,
                        face_distance
                    ) = recognizer.predict(
                        face
                    )


                    # ==================================================
                    # PERCENTAGE
                    # ==================================================

                    percentage = (
                        calculate_percentage(
                            face_distance
                        )
                    )


                    # Debug output
                    print(
                        "[FACE]",
                        "ID:",
                        predicted_id,
                        "Distance:",
                        round(
                            face_distance,
                            2
                        ),
                        "Score:",
                        percentage,
                        "%"
                    )


                    # ==================================================
                    # POSSIBLE ROYDEN / YIWEN
                    # ==================================================

                    if (
                        predicted_id in NAMES
                        and
                        face_distance
                        <=
                        UNKNOWN_THRESHOLD
                    ):


                        predicted_name = (
                            NAMES[
                                predicted_id
                            ]
                        )


                        # ------------------------------------------
                        # SAME PERSON AS PREVIOUS MATCH
                        # ------------------------------------------

                        if (
                            current_candidate
                            ==
                            predicted_id
                        ):

                            match_count += 1


                        # ------------------------------------------
                        # DIFFERENT PERSON
                        # ------------------------------------------

                        else:

                            current_candidate = (
                                predicted_id
                            )

                            match_count = 1

                            score_history.clear()


                        # ------------------------------------------
                        # SAVE SCORE
                        # ------------------------------------------

                        score_history.append(
                            percentage
                        )


                        if (
                            len(score_history)
                            >
                            MAX_SCORE_HISTORY
                        ):

                            score_history.pop(0)


                        # ------------------------------------------
                        # CALCULATE AVERAGE
                        # ------------------------------------------

                        average_percentage = int(
                            sum(score_history)
                            /
                            len(score_history)
                        )


                        # ==================================================
                        # FINAL RECOGNITION
                        # ==================================================

                        if (
                            match_count
                            >=
                            MATCH_REQUIRED
                            and
                            average_percentage
                            >=
                            MIN_KNOWN_PERCENTAGE
                        ):


                            name = (
                                predicted_name
                            )


                            percentage = (
                                average_percentage
                            )


                            color = (
                                0,
                                255,
                                0
                            )


                            open_door(
                                predicted_name
                            )


                        # ==================================================
                        # STILL CHECKING
                        # ==================================================

                        else:


                            name = (
                                "Checking "
                                +
                                predicted_name
                                +
                                " "
                                +
                                str(match_count)
                                +
                                "/"
                                +
                                str(MATCH_REQUIRED)
                            )


                            percentage = (
                                average_percentage
                            )


                            color = (
                                0,
                                255,
                                255
                            )


                    # ==================================================
                    # UNKNOWN PERSON
                    # ==================================================

                    else:


                        reset_recognition()


                        name = "Unknown"


                        # Keep Unknown display lower
                        # This does NOT affect actual recognition
                        if percentage > 55:

                            percentage = 55


                        color = (
                            0,
                            0,
                            255
                        )


                    # ==================================================
                    # SAVE RESULT
                    # ==================================================

                    recognition_results.append(
                        (
                            x,
                            y,
                            w,
                            h,
                            name,
                            percentage,
                            color
                        )
                    )


            # ==================================================
            # DRAW FACE RESULTS
            # ==================================================

            for result in recognition_results:


                (
                    x,
                    y,
                    w,
                    h,
                    name,
                    percentage,
                    color
                ) = result


                # Face box
                cv2.rectangle(
                    img,
                    (x, y),
                    (
                        x + w,
                        y + h
                    ),
                    color,
                    2
                )


                # Person name
                cv2.putText(
                    img,
                    name,
                    (
                        x,
                        y - 8
                    ),
                    font,
                    0.5,
                    color,
                    2
                )


                # Percentage
                cv2.putText(
                    img,
                    "{}%".format(
                        percentage
                    ),
                    (
                        x,
                        y + h + 20
                    ),
                    font,
                    0.6,
                    color,
                    2
                )


        # ==================================================
        # OUTSIDE 40 CM
        # ==================================================

        else:


            recognition_results = []


            reset_recognition()


            if distance == 999:


                cv2.putText(
                    img,
                    "Ultrasonic: NO ECHO",
                    (10, 45),
                    font,
                    0.45,
                    (0, 0, 255),
                    1
                )


            else:


                cv2.putText(
                    img,
                    "Face Recognition: OFF",
                    (10, 45),
                    font,
                    0.45,
                    (0, 0, 255),
                    1
                )


                cv2.putText(
                    img,
                    "Move within 40 cm",
                    (10, 70),
                    font,
                    0.45,
                    (0, 0, 255),
                    1
                )


        # ==================================================
        # DISPLAY CAMERA
        # ==================================================

        cv2.imshow(
            "Smart Door Face Recognition",
            img
        )


        key = (
            cv2.waitKey(1)
            &
            0xff
        )


        # ESC
        if key == 27:

            break


# ==================================================
# CTRL+C
# ==================================================

except KeyboardInterrupt:

    print(
        "[INFO] Program stopped"
    )


# ==================================================
# CLEANUP
# ==================================================

finally:


    print(
        "[INFO] Exiting"
    )


    # Buzzer OFF
    GPIO.output(
        BUZZER_PIN,
        GPIO.LOW
    )


    # Close door
    set_servo_angle(
        0
    )


    servo.stop()


    cam.release()


    cv2.destroyAllWindows()


    GPIO.cleanup()