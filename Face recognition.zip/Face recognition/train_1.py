import cv2
import numpy as np
import os

DATASET_PATH = '/home/pi/Desktop/IFR/dataset'
MODEL_PATH = '/home/pi/Desktop/IFR/recognizer.xml'
CASCADE_PATH = '/home/pi/Desktop/IFR/haarcascade_frontalface_default.xml'

FACE_SIZE = (200, 200)

# Person IDs
PEOPLE = {
    "Royden": 1,
    "Yiwen": 2
}

recognizer = cv2.face.LBPHFaceRecognizer_create()
face_detector = cv2.CascadeClassifier(CASCADE_PATH)

faces_list = []
ids_list = []

royden_count = 0
yiwen_count = 0

print("[INFO] Starting training...")

# Check cascade file
if face_detector.empty():
    print("[ERROR] Cannot load Haar Cascade file")
    exit()

# Go through every image inside dataset
for filename in os.listdir(DATASET_PATH):

    file_path = os.path.join(DATASET_PATH, filename)

    # Skip folders
    if not os.path.isfile(file_path):
        continue

    # ------------------------------------------
    # FIND PERSON USING FILENAME
    # ------------------------------------------

    person_name = None
    person_id = None

    if filename.lower().startswith("royden"):
        person_name = "Royden"
        person_id = 1

    elif filename.lower().startswith("yiwen"):
        person_name = "Yiwen"
        person_id = 2

    else:
        print("[SKIP] Unknown filename:", filename)
        continue


    # ------------------------------------------
    # READ IMAGE
    # ------------------------------------------

    image = cv2.imread(
        file_path,
        cv2.IMREAD_GRAYSCALE
    )

    if image is None:
        print("[WARNING] Cannot read:", filename)
        continue


    # Improve contrast
    image = cv2.equalizeHist(image)


    # ------------------------------------------
    # DETECT FACE
    # ------------------------------------------

    faces = face_detector.detectMultiScale(
        image,
        scaleFactor=1.1,
        minNeighbors=4,
        minSize=(40, 40)
    )


    if len(faces) == 0:
        print("[WARNING] No face detected:", filename)
        continue


    # ------------------------------------------
    # USE LARGEST FACE
    # ------------------------------------------

    largest_face = max(
        faces,
        key=lambda face: face[2] * face[3]
    )

    x, y, w, h = largest_face

    face = image[
        y:y+h,
        x:x+w
    ]

    face = cv2.resize(
        face,
        FACE_SIZE
    )


    # Add face and ID
    faces_list.append(face)
    ids_list.append(person_id)


    # Count images
    if person_id == 1:
        royden_count += 1

    elif person_id == 2:
        yiwen_count += 1


    print(
        "[INFO] Added:",
        person_name,
        "-",
        filename
    )


# ------------------------------------------
# CHECK IF FACES FOUND
# ------------------------------------------

if len(faces_list) == 0:

    print("")
    print("[ERROR] No faces found in dataset")
    print("[INFO] Make sure filenames start with Royden or Yiwen")
    exit()


# ------------------------------------------
# TRAIN MODEL
# ------------------------------------------

recognizer.train(
    faces_list,
    np.array(ids_list)
)


# ------------------------------------------
# SAVE MODEL
# ------------------------------------------

recognizer.save(
    MODEL_PATH
)


# ------------------------------------------
# RESULTS
# ------------------------------------------

print("")
print("====================================")
print("[INFO] Training completed")
print("====================================")

print("[INFO] Royden images used:", royden_count)
print("[INFO] Yiwen images used:", yiwen_count)
print("[INFO] Total images used:", len(faces_list))

print("")
print("[INFO] Royden ID = 1")
print("[INFO] Yiwen ID = 2")

print("")
print("[INFO] Model saved to:")
print(MODEL_PATH)

cv2.destroyAllWindows()
